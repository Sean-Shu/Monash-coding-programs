package com.example.testa3.API;

import com.google.gson.JsonSerializationContext;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class MovieSearchAPI {
    private static final String api_key = "346785445bad4b94e67bb7cf88cd137a";

    public static String searchMovie(String keyword){
        keyword = keyword.trim().replace(" ","%20");
        URL url = null;
        HttpURLConnection uc = null;
        String res = "";
        try {
            url = new URL("https://api.themoviedb.org/3/search/movie?api_key=" + api_key + "&language=en-US&query=" + keyword + "&page=1&include_adult=false");
            uc = (HttpURLConnection) url.openConnection();
            uc.setReadTimeout(9999);
            uc.setConnectTimeout(20000);
            uc.setRequestMethod("GET");
            //System.out.print("URL IS" + url);
            uc.setRequestProperty("Content-Type", "application/json");
            uc.setRequestProperty("Accept", "application/json");
            Scanner streamReader = new Scanner(uc.getInputStream());
            while (streamReader.hasNextLine()) {
                res += streamReader.nextLine();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            uc.disconnect();
        }
        return res;
    }

    public static List<String> getSnippet(String res){
        List<String> snippet = new ArrayList<>();
        try{
            JSONObject jsobj = new JSONObject(res);
            JSONArray ja = new JSONArray(jsobj.getString("results"));
            if(ja.length()>15){
                for(int i = 0; i < 15; i++){
                    JSONObject jo = (JSONObject) ja.get(i);
                    snippet.add(jo.getString("title"));
                    snippet.add(jo.getString("release_date"));
                    snippet.add(jo.getString("id"));
                    snippet.add(jo.getString("poster_path"));
                }
            }else{
                for(int i = 0; i < ja.length();i++){
                    JSONObject jo = (JSONObject) ja.get(i);
                    snippet.add(jo.getString("title"));
                    snippet.add(jo.getString("release_date"));
                    snippet.add(jo.getString("id"));
                    snippet.add(jo.getString("poster_path"));
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return snippet;
    }

    public static String getMovieData(String movieID){
        URL url = null;
        HttpURLConnection uc = null;//Movie details url https://api.themoviedb.org/3/movie/597?api_key=346785445bad4b94e67bb7cf88cd137a&language=en-US
        String textRes = "";//Movie credit url https://api.themoviedb.org/3/movie/597/credits?api_key=346785445bad4b94e67bb7cf88cd137a
        try{
            url = new URL("https://api.themoviedb.org/3/movie/" + movieID + "?api_key=" + api_key + "&language=en-US");
            uc = (HttpURLConnection) url.openConnection();
            uc.setReadTimeout(9999);
            uc.setConnectTimeout(20000);
            uc.setRequestMethod("GET");
            uc.setRequestProperty("Content-Type", "application/json");
            uc.setRequestProperty("Accept", "application/json");
            Scanner streamReader = new Scanner(uc.getInputStream());
            while (streamReader.hasNextLine()) {
                textRes += streamReader.nextLine();
            }
        }catch(Exception e){
            e.printStackTrace();
        }finally {
            uc.disconnect();
        }
        return textRes;
    }

    public static String getMovieCast(String movieID){
        URL url = null;
        HttpURLConnection uc = null;//Movie details url https://api.themoviedb.org/3/movie/597?api_key=346785445bad4b94e67bb7cf88cd137a&language=en-US
        String textRes = "";//Movie credit url https://api.themoviedb.org/3/movie/597/credits?api_key=346785445bad4b94e67bb7cf88cd137a
        try{
            url = new URL("https://api.themoviedb.org/3/movie/" + movieID + "/credits?api_key=" + api_key);
            uc = (HttpURLConnection) url.openConnection();
            uc.setReadTimeout(9999);
            uc.setConnectTimeout(20000);
            uc.setRequestMethod("GET");
            uc.setRequestProperty("Content-Type", "application/json");
            uc.setRequestProperty("Accept", "application/json");
            Scanner streamReader = new Scanner(uc.getInputStream());
            while (streamReader.hasNextLine()) {
                textRes += streamReader.nextLine();
            }
        }catch(Exception e){
            e.printStackTrace();
        }finally {
            uc.disconnect();
        }
        return textRes;
    }

    public static HashMap<String, Object> movieDataFilt(String resDetail, String resCredit){
        HashMap<String, Object> snippet= new HashMap<>();
        try {
            JSONObject joDetail = new JSONObject(resDetail);
            snippet.put("overview",joDetail.getString("overview"));
            snippet.put("release date",joDetail.getString("release_date"));
            snippet.put("rating score",joDetail.getString("vote_average"));
            snippet.put("imgURL",joDetail.get("poster_path"));

            JSONArray jsArrayGenre = joDetail.getJSONArray("genres");
            JSONObject joGenre = jsArrayGenre.getJSONObject(0);
            snippet.put("genre",joGenre.getString("name"));

            JSONArray jsArrayCountry = joDetail.getJSONArray("production_countries");
            JSONObject joCountry = jsArrayCountry.getJSONObject(0);
            snippet.put("country",joCountry.getString("name"));


            JSONObject joCredit = new JSONObject(resCredit);
            JSONArray jaCredit = joCredit.getJSONArray("cast");
            List<String> castList = new ArrayList<>();
            if(jaCredit.length() < 4){
                for(int i = 0; i < jaCredit.length(); i++){
                    JSONObject joResCast = jaCredit.getJSONObject(i);
                    castList.add(joResCast.getString("name"));
                }
            }
            else{
                for(int i = 0; i < 4; i++){
                    JSONObject joResCast = jaCredit.getJSONObject(i);
                    castList.add(joResCast.getString("name"));
                }
            }
            snippet.put("castList",castList);

            JSONArray jaCrew = joCredit.getJSONArray("crew");
            List<String> dirList = new ArrayList<>();
            for(int i = 0; i < jaCrew.length(); i++){
                JSONObject joResCrew = jaCrew.getJSONObject(i);
                if(joResCrew.getString("job").equals("Director")){
                    dirList.add(joResCrew.getString("name"));
                }
            }
            snippet.put("directorList",dirList);

        }catch(JSONException je){
            je.printStackTrace();
        }
        return snippet;
    }

}
