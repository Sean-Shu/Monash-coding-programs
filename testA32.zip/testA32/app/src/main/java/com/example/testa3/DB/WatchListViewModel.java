package com.example.testa3.DB;

import android.app.Application;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

public class WatchListViewModel extends ViewModel {
    private WatchListRepository watchListRepository;
    private MutableLiveData<List<WatchList>> allOfTheWatchList;

    public WatchListViewModel(){
        allOfTheWatchList = new MutableLiveData<>();
    }

    public void setWatchList(List<WatchList> watchList){
        allOfTheWatchList.setValue(watchList);
    }

    public LiveData<List<WatchList>> getAllOfTheWatchList(String personId){
        return watchListRepository.getAllWatchList(personId);
    }

    public List<WatchList> getWatchListById(String personId){
        return watchListRepository.getAllWatchListById(personId);
    }

    public void initalizeVars(Application app){
        watchListRepository = new WatchListRepository(app);
    }

    public void insert(WatchList watchList) {
        watchListRepository.insert(watchList);
    }

    public void insertAll(WatchList watchList) {
        watchListRepository.insertAll(watchList);
    }

    public void deleteAll() {
        watchListRepository.deleteAll();
    }

    public void delete(WatchList watchList){
        watchListRepository.delete(watchList);
    }

    public void deleteById(int watchId){
        watchListRepository.deleteById(watchId);
    }

    public void update(WatchList... watchList) {
        watchListRepository.updateWatchList(watchList);
    }

    public WatchList insertAll(int id) {
        return watchListRepository.findById(id);
    }

    public WatchList findByID(int watchListId){
        return watchListRepository.findById(watchListId); }
}
