package com.example.testa3.DB;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import static androidx.room.OnConflictStrategy.REPLACE;

@Dao
public interface WatchListDAO {
    @Query("SELECT * FROM watchlist")
    List<WatchList> getAll();

    @Query("SELECT * FROM watchlist WHERE watchid = :watchId LIMIT 1")
    WatchList findById(int watchId);

    @Query("SELECT * FROM watchlist WHERE personid = :personid")
    LiveData<List<WatchList>> findByPersonId(String personid);

    @Query("SELECT * FROM watchlist WHERE personid = :personid")
    List<WatchList> findByPersonIdList(String personid);

    @Insert
    void insertAll(WatchList...watchList);

    @Insert
    long insert(WatchList watchList);

    @Delete
    void delete(WatchList watchList);

    @Update(onConflict = REPLACE)
    public void updateWatchList(WatchList... watchList);

    @Query("DELETE FROM WatchList")
    void deleteAll();

    @Query("DELETE FROM WatchList WHERE watchid = :watchid")
    void deleteById(int watchid);
}
