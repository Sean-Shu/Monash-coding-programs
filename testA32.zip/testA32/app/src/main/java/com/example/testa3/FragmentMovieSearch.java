package com.example.testa3;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.example.testa3.API.MovieSearchAPI;

import java.io.IOError;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class FragmentMovieSearch extends Fragment {
    private View movieSearchView;
    private Button searchMovieButton;
    private EditText movieSearchText;
    private String keyword;
    private List<String> resList = new ArrayList<>();
    private ListView movieListLV;
    private List<HashMap<String,Object>> searchResArray = new ArrayList<>();
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saveInstanceState){
        movieSearchView = inflater.inflate(R.layout.activity_fragment_movie_search, container, false);
        searchMovieButton = (Button) movieSearchView.findViewById(R.id.searchMovieButton);
        movieSearchText = (EditText) movieSearchView.findViewById(R.id.movieSearch);
        movieListLV = (ListView) movieSearchView.findViewById(R.id.movieListSearchPage);
        searchMovieButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                keyword = movieSearchText.getText().toString();
                new AsyncSearch().execute(keyword);
            }
        });
        return movieSearchView;
    }

    private class AsyncSearch extends AsyncTask<String, Void, String>{

        @Override
        protected String doInBackground(String... params) {
            return MovieSearchAPI.searchMovie(params[0]);
        }
        @Override
        protected void onPostExecute(String res){
            new AsyncList().execute(res);
        }
    }
    private class AsyncList extends AsyncTask<String, Void, SimpleAdapter>{

        @Override
        protected SimpleAdapter doInBackground(String... params) {
            resList = MovieSearchAPI.getSnippet(params[0]);
            for(int i = 0; i < resList.size(); i += 4){
                HashMap<String,Object> hmap = new HashMap<>();
                hmap.put("Movie Name",resList.get(i));
                hmap.put("Release Date",resList.get(i+1));
                hmap.put("movieID",resList.get(i+2));
                String imgLink = "https://image.tmdb.org/t/p/w1280" + resList.get(i+3);
                Bitmap bmap;
                try{
                    URL url = new URL(imgLink);
                    InputStream inStream = url.openStream();
                    bmap = BitmapFactory.decodeStream(inStream);
                    inStream.close();
                    hmap.put("image",bmap);
                }catch (IOError | IOException e){
                    e.printStackTrace();
                }
                searchResArray.add(hmap);
            }
            String[] header = new String[]{"image","Movie Name","Release Date","movieID"};
            int[] data = new int[]{R.id.movieImg,R.id.resMovieName,R.id.resReleaseDate,R.id.resMovieId};
            SimpleAdapter sa = new SimpleAdapter(FragmentMovieSearch.this.getActivity(),searchResArray,R.layout.list_search_result,header,data);

            sa.setViewBinder(new SimpleAdapter.ViewBinder() {
                @Override
                public boolean setViewValue(View view, Object data, String textRepresentation) {
                    if((view instanceof ImageView) & (data instanceof Bitmap)){
                        ImageView iv = (ImageView) view;
                        Bitmap bm = (Bitmap) data;
                        iv.setImageBitmap(bm);
                        return true;
                    }
                    return false;
                }
            });
            return sa;
        }

        @Override
        protected void onPostExecute(SimpleAdapter sa){
            movieListLV.setAdapter(sa);
            movieListLV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    String movieId = searchResArray.get(position).get("movieID").toString();
                    String movieName = searchResArray.get(position).get("Movie Name").toString();
                    String releaseDate = searchResArray.get(position).get("Release Date").toString();
                    Fragment newFrag = new FragmentMovieDetails();
                    Bundle arg = new Bundle();
                    arg.putString("idOfMovie",movieId);
                    arg.putString("nameOfMovie",movieName);
                    arg.putString("releaseDateOfMovie", releaseDate);
                    arg.putString("key", "true");
                    newFrag.setArguments(arg);
                    FragmentManager fm = getFragmentManager();
                    fm.beginTransaction().replace(R.id.content_frame,newFrag).commit();
                }
            });
        }
    }
}
