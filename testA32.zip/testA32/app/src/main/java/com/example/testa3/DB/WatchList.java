package com.example.testa3.DB;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class WatchList {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "watchid")
    public int watchid;

    @ColumnInfo(name = "movieName")
    public String movieName;

    @ColumnInfo(name = "releaseDate")
    public String releaseDate;

    @ColumnInfo(name = "addDate")
    public String addDate;

    @ColumnInfo(name = "addTime")
    public String addTime;

    @ColumnInfo(name = "personid")
    public String personid;

    @ColumnInfo(name = "movieid")
    public String movieid;

    public WatchList( String movieName, String releaseDate, String addDate, String addTime, String personid, String movieid) {
        this.movieName = movieName;
        this.releaseDate = releaseDate;
        this.addDate = addDate;
        this.addTime = addTime;
        this.personid = personid;
        this.movieid = movieid;
    }

    public WatchList() {

    }

    public int getWatchid() {
        return watchid;
    }

    public void setWatchid(int watchid) {
        this.watchid = watchid;
    }

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getAddDate() {
        return addDate;
    }

    public void setAddDate(String addDate) {
        this.addDate = addDate;
    }

    public String getAddTime() {
        return addTime;
    }

    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }

    public String getPersonid() {
        return personid;
    }

    public void setPersonid(String personid) {
        this.personid = personid;
    }

    public String getMovieid() {
        return movieid;
    }

    public void setMovieid(String movieid) {
        this.movieid = movieid;
    }
}
