package com.example.testa3.DB;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;

public class WatchListRepository {
    private WatchListDAO dao;
    private LiveData<List<WatchList>> allWatchlist;
    private WatchList watchList;
    private List<WatchList> watchLists;

    public WatchListRepository(Application app){
        WatchListDB db = WatchListDB.getINSTANCE(app);
        dao = db.watchListDAO();
    }

    public LiveData<List<WatchList>> getAllWatchList(String personId){
        allWatchlist = dao.findByPersonId(personId);
        return allWatchlist;
    }

    public List<WatchList> getAllWatchListById(String personId){
        watchLists = dao.findByPersonIdList(personId);
        return watchLists;
    }

    public void insert(final WatchList watchList){
        WatchListDB.databaseWriteExecutor.execute(new Runnable() {
            @Override
            public void run() {
                dao.insert(watchList);
            } });
    }

    public void deleteAll(){
        WatchListDB.databaseWriteExecutor.execute(new Runnable() {
            @Override
            public void run() {
                dao.deleteAll();
            } });
    }

    public void delete(final WatchList watchList){
        WatchListDB.databaseWriteExecutor.execute(new Runnable() {
            @Override
            public void run() {
                dao.delete(watchList);
            } });
    }

    public void deleteById(final int watchId){
        WatchListDB.databaseWriteExecutor.execute(new Runnable() {
            @Override
            public void run() {
                dao.deleteById(watchId);
            } });
    }

    public void insertAll(final WatchList... watchlist){
        WatchListDB.databaseWriteExecutor.execute(new Runnable() {
            @Override
            public void run() {
                dao.insertAll(watchlist);
            } });
    }

    public void updateWatchList(final WatchList... watchlist){
        WatchListDB.databaseWriteExecutor.execute(new Runnable() {
            @Override
            public void run() {
                dao.updateWatchList(watchlist);
            } });
    }

    public WatchList findById(final int watchListId){
        WatchListDB.databaseWriteExecutor.execute(new Runnable() {
            @Override
            public void run() {
                WatchList runWatchList = dao.findById(watchListId);
                setWatchList(runWatchList);
            }
        });
        return watchList;
    }

    public void setWatchList(WatchList watchList){
        this.watchList = watchList;
    }
}
