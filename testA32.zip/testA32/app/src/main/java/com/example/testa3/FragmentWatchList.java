package com.example.testa3;


import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Observer;

import com.example.testa3.DB.WatchList;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class FragmentWatchList extends Fragment {
    private View watchListView;
    private List<HashMap<String,String>> watchListHmap = new ArrayList<>();
    private ListView watchListLV;
    private String movieId;
    private String watchId;
    private TextView selectItem;
    private Button movieViewButton;
    private Button deleteMovieButton;
    private String movieName;
    private SimpleAdapter sa;
    private AlertDialog.Builder ad;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saveInstanceState){
        watchListView = inflater.inflate(R.layout.activity_fragment_watch_list, container, false);
        watchListLV = watchListView.findViewById(R.id.watch_list);
        selectItem = watchListView.findViewById(R.id.selectItem);
        movieViewButton = watchListView.findViewById(R.id.viewMovieButton);
        deleteMovieButton = watchListView.findViewById(R.id.deleteMovieButton);

        selectItem.setVisibility(View.INVISIBLE);
        movieViewButton.setVisibility(View.INVISIBLE);
        deleteMovieButton.setVisibility(View.INVISIBLE);

        MenuFragment.watchListViewModel.getAllOfTheWatchList(String.valueOf(Login.personid)).observe(getViewLifecycleOwner(), new Observer<List<WatchList>>() {
            @Override
            public void onChanged(List<WatchList> watchLists) {
                watchListHmap.clear();
                for(WatchList currentwl:watchLists){
                    HashMap<String,String> hmap = new HashMap<>();
                    hmap.put("movie name",currentwl.getMovieName());
                    hmap.put("watch id",String.valueOf(currentwl.getWatchid()));
                    hmap.put("movie id",currentwl.getMovieid());
                    hmap.put("release date",currentwl.getReleaseDate());
                    hmap.put("date of add",currentwl.getAddDate());
                    hmap.put("time of add",currentwl.getAddTime());
                    watchListHmap.add(hmap);
                }
                String[] header = new String[]{"movie name","watch id","movie id","release date","date of add","time of add"
                };
                int[] data = new int[]{R.id.movieNameInListWatchList,R.id.watchIdWatchList,R.id.movieIdWatchList,R.id.releaseDateInListWatchList,R.id.addDateInListWatchList,R.id.addTimeInListWatchList};
                sa = new SimpleAdapter(FragmentWatchList.this.getActivity(),watchListHmap,R.layout.list_watch_list,header,data);
                watchListLV.setAdapter(sa);
            }
        });
        watchListLV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                movieId = watchListHmap.get(position).get("movie id");
                watchId = watchListHmap.get(position).get("watch id");
                movieName = watchListHmap.get(position).get("movie name");
                selectItem.setText("Selected movie:" + movieName);
                selectItem.setVisibility(View.VISIBLE);
                movieViewButton.setVisibility(View.VISIBLE);
                deleteMovieButton.setVisibility(View.VISIBLE);
            }
        });

        movieViewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment newFrag = new FragmentMovieDetails();
                Bundle arg = new Bundle();
                arg.putString("idOfMovie",movieId);
                arg.putString("nameOfMovie",movieName);
                arg.putString("key","false");
                newFrag.setArguments(arg);
                FragmentManager fm = getFragmentManager();
                fm.beginTransaction().replace(R.id.content_frame,newFrag).commit();
            }
        });

        deleteMovieButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ad = new AlertDialog.Builder(FragmentWatchList.this.getActivity());
                ad.setTitle("Do you wish to delete?");
                ad.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        MenuFragment.watchListViewModel.deleteById(Integer.parseInt(watchId));
                        selectItem.setVisibility(View.INVISIBLE);
                        movieViewButton.setVisibility(View.INVISIBLE);
                        deleteMovieButton.setVisibility(View.INVISIBLE);
                        Toast.makeText(watchListView.getContext(),"The movie is deleted from the watch list",Toast.LENGTH_SHORT).show();
                    }
                });
                ad.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                ad.show();
            }
        });

        return watchListView;
    }
}
