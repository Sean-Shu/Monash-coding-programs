package com.example.testa3;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.net.Credentials;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.testa3.resources.MD5;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class signup extends AppCompatActivity {

    private Map<String, EditText> editTextMap = new HashMap<String, EditText>();
    private List<String> usernameList = new ArrayList<>();
    private String gender = "F";
    private String state;
    private String signUpDate;
    private String personDob;
    private int exit = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        Button dateChooseButton = (Button) findViewById(R.id.dateChoseButton);
        Button submitButton = (Button) findViewById(R.id.submitButton);

        editTextMap.put("firstname",(EditText)findViewById(R.id.firstname));
        editTextMap.put("lastname",(EditText)findViewById(R.id.lastname));
        editTextMap.put("address",(EditText)findViewById(R.id.address));
        editTextMap.put("postcode",(EditText)findViewById(R.id.postcode));
        editTextMap.put("email",(EditText)findViewById(R.id.email));
        editTextMap.put("password",(EditText)findViewById(R.id.password));

        final TextView dateChoose = (TextView) findViewById(R.id.dateOfBirth);

        Spinner state_spinner = (Spinner) findViewById(R.id.state_spinner);

        new AsyncGetUserName().execute();

        RadioGroup rg = (RadioGroup) findViewById(R.id.genderGroup);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton rb = (RadioButton) findViewById(checkedId);
                if(rb.getText().equals("M")){
                    gender = "M";
                }
                else{
                    gender = "F";
                }
            }
        });

        List<String> statesList = new ArrayList<>();
        statesList.add("NSW");
        statesList.add("VIC");
        statesList.add("QLD");
        statesList.add("SA");
        statesList.add("WA");
        statesList.add("NT");
        statesList.add("ACT");
        statesList.add("TAS");
        final ArrayAdapter<String> stateSpinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, statesList);
        stateSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        state_spinner.setAdapter(stateSpinnerAdapter);
        state_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String choosenState = parent.getItemAtPosition(position).toString();
                if(choosenState != null){
                    state = choosenState;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        dateChooseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cld = Calendar.getInstance();
                int getYear = cld.get(Calendar.YEAR);
                int getMonth = cld.get(Calendar.MONTH);
                final int getDay = cld.get(Calendar.DAY_OF_MONTH);
                int nextMonth = getMonth + 1;
                String month;
                if(nextMonth < 10){
                    StringBuffer strb = new StringBuffer("0");
                    month = strb.append(nextMonth).toString();
                }
                else{
                    month = String.valueOf(nextMonth);
                }
                String date = "";
                if(getDay < 10){
                    StringBuffer strb = new StringBuffer("0");
                    date = strb.append(getDay).toString();
                }
                else{
                    date = String.valueOf(getDay);
                }
                String currentDate = getYear + "-" + month + "-" + date;
                StringBuffer strbTime = new StringBuffer(currentDate);
                signUpDate = strbTime.append("T00:00:00+10:00").toString();
                DatePickerDialog dpd = new DatePickerDialog(signup.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int dpdMonth, int dOm) {
                        String m = "";
                        int mm = dpdMonth + 1;
                        if (mm < 10){
                            StringBuffer strb = new StringBuffer("0");
                            m = strb.append(mm).toString();
                        }
                        else{
                            m = String.valueOf(mm);
                        }
                        String d = "";
                        if(dOm < 10){
                            StringBuffer strb = new StringBuffer("0");
                            d = strb.append(dOm).toString();
                        }else{
                            d = String.valueOf(dOm);
                        }
                        String dateOfBirth = year + "-" + m + "-" + d;
                        dateChoose.setText(dateOfBirth);
                        StringBuffer strbDc = new StringBuffer(dateOfBirth);
                        personDob = strbDc.append("T00:00:00+10:00").toString();


                    }
                },getYear,getMonth,getDay);
                DatePicker limitDp = dpd.getDatePicker();
                limitDp.setMaxDate(System.currentTimeMillis());
                dpd.show();
            }
        });

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean sign = true;
                String finalUserName = editTextMap.get("email").getText().toString();
                for(int i = 0; i < usernameList.size(); i++){
                    if (finalUserName == usernameList.get(i)){
                        sign = false;
                        editTextMap.get("email").setError("The email already exists");
                    }
                }
                Person p = new Person();
                p.setFirstname(editTextMap.get("firstname").getText().toString());
                p.setLastname(editTextMap.get("lastname").getText().toString());
                p.setAddress(editTextMap.get("address").getText().toString());
                p.setPostcode(editTextMap.get("postcode").getText().toString());
                p.setDateofbirth(personDob);
                char g=gender.charAt(0);
                p.setGender(g);
                p.setState(state);
                new AsyncUploadUser().execute(p);
                while(exit != 2){
                    if(exit == 1){
                        new AsyncGetPersonId().execute(p);
                        exit = 2;
                    }
                }
                Intent i = new Intent(signup.this, Login.class);
                startActivity(i);
            }
        });
    }

    private class AsyncGetUserName extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {
            String res = "";
            URL url = null;
            HttpURLConnection uc = null;
            final String methodLink = "a1Renew.credentials/findAllUsername";
            try {
                url = new URL(Login.HomeUrl + methodLink);
                uc = (HttpURLConnection) url.openConnection();
                uc.setReadTimeout(9999);
                uc.setConnectTimeout(20000);
                uc.setRequestMethod("GET");
                //System.out.print("URL IS" + url);
                uc.setRequestProperty("Content-Type", "application/json");
                uc.setRequestProperty("Accept", "application/json");
                Scanner streamReader = new Scanner(uc.getInputStream());
                while (streamReader.hasNextLine()) {
                    res += streamReader.nextLine();
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                uc.disconnect();
            }

            try{
                JSONArray jsArray = new JSONArray(res);
                for(int i = 0; i < jsArray.length(); i++){
                    JSONObject jsObj = (JSONObject) jsArray.get(i);
                    usernameList.add(jsObj.getString("username"));
                }
            }
            catch(JSONException je){
                je.printStackTrace();
            }
            return null;
        }
    }

    private class AsyncUploadUser extends AsyncTask<Person, Void, Person> {

        @Override
        protected Person doInBackground(Person... person) {
            URL url = null;
            HttpURLConnection uc = null;
            final String methodLink = "a1Renew.person/";
            try {
                Gson gson = new Gson();
                String strPersonJson = gson.toJson(person[0]);
                String bracketReplace = strPersonJson.replace("[","").replace("]","");
                url = new URL(Login.HomeUrl + methodLink);
                uc = (HttpURLConnection) url.openConnection();
                uc.setReadTimeout(9999);
                uc.setConnectTimeout(20000);
                uc.setRequestMethod("POST");
                uc.setDoOutput(true);
                uc.setFixedLengthStreamingMode(bracketReplace.getBytes().length);
                uc.setRequestProperty("Content-Type","application/json");
                PrintWriter out = new PrintWriter(uc.getOutputStream());
                out.print(bracketReplace);
                out.flush();
                out.close();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                uc.disconnect();
            }
            exit = 1;
            return person[0];
        }
    }

    private class AsyncGetPersonId extends AsyncTask<Person, Void, Person> {

        @Override
        protected Person doInBackground(Person... person) {
            String res = "";
            URL url = null;
            HttpURLConnection uc = null;
            final String methodLink = "a1Renew.person/getLatestPersonId";
            try {
                url = new URL(Login.HomeUrl + methodLink);
                uc = (HttpURLConnection) url.openConnection();
                uc.setReadTimeout(9999);
                uc.setConnectTimeout(20000);
                uc.setRequestMethod("GET");
                //System.out.print("URL IS" + url);
                uc.setRequestProperty("Content-Type", "application/json");
                uc.setRequestProperty("Accept", "application/json");
                Scanner streamReader = new Scanner(uc.getInputStream());
                while (streamReader.hasNextLine()) {
                    res += streamReader.nextLine();
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                uc.disconnect();
            }
            try{
                JSONObject jsObj = new JSONObject(res);
                person[0].setPersonid(jsObj.getInt("personid"));
            }
            catch(JSONException je){
                je.printStackTrace();
            }
            return person[0];
        }
        }

        protected void onPostExecute(Person p){
            Credential c = new Credential();
            c.setPersonid(p.getPersonid());
            c.setPasswordHash(MD5.md5(editTextMap.get("password").getText().toString()));
            c.setUserName(editTextMap.get("email").getText().toString());
            c.setSignUpDate(signUpDate);
            new AsyncUploadCredential().execute(c);
        }

    private class AsyncUploadCredential extends AsyncTask<Credential, Void, Void> {

            @Override
            protected Void doInBackground(Credential... c) {
                URL url = null;
                HttpURLConnection uc = null;
                final String methodLink = "a1Renew.credentials/";
                try {
                    Gson gson = new Gson();
                    String strCredentialJson = gson.toJson(c);
                    String bracketRemove = strCredentialJson.replace("[","").replace("]","");
                    url = new URL(Login.HomeUrl + methodLink);
                    uc = (HttpURLConnection) url.openConnection();
                    uc.setReadTimeout(9999);
                    uc.setConnectTimeout(20000);
                    uc.setRequestMethod("POST");
                    uc.setDoOutput(true);
                    uc.setFixedLengthStreamingMode(bracketRemove.getBytes().length);
                    uc.setRequestProperty("Content-Type","application/json");
                    PrintWriter out = new PrintWriter(uc.getOutputStream());
                    out.print(bracketRemove);
                    out.flush();
                    out.close();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    uc.disconnect();
                }
                return null;
            }

        }
    }
