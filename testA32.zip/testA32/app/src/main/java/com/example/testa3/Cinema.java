package com.example.testa3;

public class Cinema {
    private String cinemaid;
    private String cinemaname;
    private String location;

    public Cinema(String cinemaid, String cinemaname, String location) {
        this.cinemaid = cinemaid;
        this.cinemaname = cinemaname;
        this.location = location;
    }

    public String getCinemaid() {
        return cinemaid;
    }

    public void setCinemaid(String cinemaid) {
        this.cinemaid = cinemaid;
    }

    public String getCinemaname() {
        return cinemaname;
    }

    public void setCinemaname(String cinemaname) {
        this.cinemaname = cinemaname;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
