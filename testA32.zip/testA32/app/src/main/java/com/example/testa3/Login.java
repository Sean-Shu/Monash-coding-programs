package com.example.testa3;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.testa3.resources.MD5;

import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class Login extends AppCompatActivity {

    private EditText accountEt;
    private EditText passwdEt;
    public static int personid;

    public static final String HomeUrl = "http://192.168.1.103:8080/fit5046a1Renew/webresources/";
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);


        accountEt = (EditText) findViewById(R.id.account);
        passwdEt = (EditText) findViewById(R.id.password);

        Button loginButton = (Button) findViewById(R.id.loginButton);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AsyncLogin().execute(accountEt.getText().toString(),passwdEt.getText().toString());
            }
        });

        Button signUpButton = (Button) findViewById(R.id.signup);
        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Login.this,signup.class);
                startActivity(i);
            }
        });

    }

    private class AsyncLogin extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {
            String res = "";
            String usn = strings[0];
            String psd = strings[1];
            String md5paswd = MD5.md5(psd);
            URL url = null;
            HttpURLConnection uc = null;
            final String methodLink = "a1Renew.credentials/findByUsernameAndPassword/";
            try {
                url = new URL(HomeUrl + methodLink + usn + "/" + md5paswd);
                uc = (HttpURLConnection) url.openConnection();
                uc.setReadTimeout(9999);
                uc.setConnectTimeout(20000);
                uc.setRequestMethod("GET");
                //System.out.print("URL IS" + url);
                uc.setRequestProperty("Content-Type", "application/json");
                uc.setRequestProperty("Accept", "application/json");
                Scanner streamReader = new Scanner(uc.getInputStream());
                while (streamReader.hasNextLine()) {
                    res += streamReader.nextLine();
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                uc.disconnect();
            }
            try{
                String bracketReplace = res.replace("[","").replace("]","");
                JSONObject jsobj = new JSONObject(bracketReplace);
                String personid1 = jsobj.getString("personid");
                JSONObject jsobj2 = new JSONObject(personid1);
                personid = Integer.parseInt(jsobj2.getString("personid"));
                String personid2 = jsobj2.getString("personid");
                SharedPreferences sharedPreferences = Login.this.getSharedPreferences(personid2,MODE_PRIVATE);
                SharedPreferences.Editor e = sharedPreferences.edit();
                e.putString("firstname",jsobj2.getString("firstname"));
                e.putString("email",usn);
                e.commit();
            }catch (Exception e){
                e.printStackTrace();
            }
            return res;
        }

        protected void onPostExecute(String res) {
            if (res.equals("[]") || res.isEmpty()) {
                Toast.makeText(Login.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            } else {
                Intent i = new Intent(Login.this, MainActivity.class);
                startActivity(i);
            }
        }
    }

}
