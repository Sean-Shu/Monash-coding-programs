package com.example.testa3;

public class Credential {
    private String username;
    private String password;
    private String signUpDate;
    private int personid;

    public String getUserName(){return username;}

    public void setUserName(String username){this.username = username;}

    public String getPasswordHash(){return password;}

    public void setPasswordHash(String paswd){this.password = paswd;}

    public String getSignUpDate(){return signUpDate;}

    public void setSignUpDate(String signUpDate){
        this.signUpDate = signUpDate;
    }

    public int getPersonId() {
        return personid;
    }

    public void setPersonid(int personid){
        this.personid = personid;
    }
}
