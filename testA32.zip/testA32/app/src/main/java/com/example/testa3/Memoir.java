package com.example.testa3;

public class Memoir {
    private String memoirid;
    private String moivename;
    private String moviereleasedate;
    private String userwatchtime;
    private String usercomment;
    private String userrating;
    private String writetime;
    private Cinema cinemaid;
    private Person personid;

    public Memoir(String memoirid,
                  String moivename,
                  String moviereleasedate,
                  String userwatchtime,
                  String usercomment,
                  String userrating,
                  String writetime, Cinema cinemaid, Person personid) {
        this.memoirid = memoirid;
        this.moivename = moivename;
        this.moviereleasedate = moviereleasedate;
        this.userwatchtime = userwatchtime;
        this.usercomment = usercomment;
        this.userrating = userrating;
        this.writetime = writetime;
        this.cinemaid = cinemaid;
        this.personid = personid;
    }

    public String getMemoirid() {
        return memoirid;
    }

    public void setMemoirid(String memoirid) {
        this.memoirid = memoirid;
    }

    public String getMoivename() {
        return moivename;
    }

    public void setMoivename(String moivename) {
        this.moivename = moivename;
    }

    public String getMoviereleasedate() {
        return moviereleasedate;
    }

    public void setMoviereleasedate(String moviereleasedate) {
        this.moviereleasedate = moviereleasedate;
    }

    public String getUserwatchtime() {
        return userwatchtime;
    }

    public void setUserwatchtime(String userwatchtime) {
        this.userwatchtime = userwatchtime;
    }

    public String getUsercomment() {
        return usercomment;
    }

    public void setUsercomment(String usercomment) {
        this.usercomment = usercomment;
    }

    public String getUserrating() {
        return userrating;
    }

    public void setUserrating(String userrating) {
        this.userrating = userrating;
    }

    public String getWritetime() {
        return writetime;
    }

    public void setWritetime(String writetime) {
        this.writetime = writetime;
    }

    public Cinema getCinemaid() {
        return cinemaid;
    }

    public void setCinemaid(Cinema cinemaid) {
        this.cinemaid = cinemaid;
    }

    public Person getPersonid() {
        return personid;
    }

    public void setPersonid(Person personid) {
        this.personid = personid;
    }
}
