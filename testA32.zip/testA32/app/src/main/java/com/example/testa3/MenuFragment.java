package com.example.testa3;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;

import com.example.testa3.DB.WatchList;
import com.example.testa3.DB.WatchListViewModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class MenuFragment extends Fragment {
    private View menuView;
    private TextView welcomeTextView;
    private TextView currentDateTextView;

    private ListView movieList;


    private List<HashMap<String, String>> movieListArray = new ArrayList<>();
    public static WatchListViewModel watchListViewModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        menuView = inflater.inflate(R.layout.fragment_menu, container, false);
        movieList = (ListView) menuView.findViewById(R.id.movieListView);
        new AsyncGetTop5().execute();
        welcomeTextView = (TextView) menuView.findViewById(R.id.welcomeUser);
        currentDateTextView = (TextView) menuView.findViewById(R.id.currentDate);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
        Date currentDate = new Date(System.currentTimeMillis());
        currentDateTextView.setText(simpleDateFormat.format(currentDate));


        return menuView;
    }

    private class AsyncGetTop5 extends AsyncTask<Void, Void, String>{

        @Override
        protected String doInBackground(Void... voids) {
            String res = "";
            URL url = null;
            HttpURLConnection uc = null;
            final String methodLink = "a1Renew.memoir/findTop5WatchingRecordsByPersonId/";
            try {
                url = new URL(Login.HomeUrl + methodLink + Login.personid);
                uc = (HttpURLConnection) url.openConnection();
                uc.setReadTimeout(9999);
                uc.setConnectTimeout(20000);
                uc.setRequestMethod("GET");
                uc.setRequestProperty("Content-Type", "application/json");
                uc.setRequestProperty("Accept", "application/json");
                Scanner streamReader = new Scanner(uc.getInputStream());
                while (streamReader.hasNextLine()) {
                    res += streamReader.nextLine();
                }
            }catch(Exception e){
                e.printStackTrace();
            }finally{
                uc.disconnect();
            }
            return res;
        }
        @Override
        protected void onPostExecute(String res){
            super.onPostExecute(res);
            JSONArray jsArray = null;
            try{
                jsArray = new JSONArray(res);
                for(int i = 0; i < jsArray.length(); i++){
                    JSONObject jsobj = (JSONObject) jsArray.get(i);
                    HashMap<String,String> hmap = new HashMap<>();
                    hmap.put("Movie Name",jsobj.getString("Moviename"));
                    hmap.put("Release Date",jsobj.getString("MovieReleaseDate"));
                    hmap.put("Rating Score",jsobj.getString("UserRating"));
                    movieListArray.add(hmap);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            String[] header = new String[]{"Movie Name", "Release Date", "Rating Score"};
            int[] data = new int[]{R.id.movieNameCell, R.id.releaseDateCell, R.id.ratingScoreCell};
            SimpleAdapter sa = new SimpleAdapter(MenuFragment.this.getActivity(),movieListArray,R.layout.movie_score_container,header,data);
            movieList.setAdapter(sa);
        }
    }

    public void onStart(){
        super.onStart();
        SharedPreferences sp = getActivity().getSharedPreferences(String.valueOf(Login.personid),Context.MODE_PRIVATE);
        String firstname = sp.getString("firstname","");
        welcomeTextView.setText("Welcome! " + firstname);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        watchListViewModel = new ViewModelProvider(this).get(WatchListViewModel.class);
        watchListViewModel.initalizeVars(getActivity().getApplication());
    }
}
