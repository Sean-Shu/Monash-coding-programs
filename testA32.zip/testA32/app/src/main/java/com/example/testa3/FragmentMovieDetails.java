package com.example.testa3;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.testa3.API.MovieSearchAPI;
import com.example.testa3.DB.WatchList;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;


public class FragmentMovieDetails extends Fragment {
    View movieView;
    private String RES;
    private TextView tvMovieName;
    private String releaseDate;
    private TextView tvMovieReleaseDate;
    private TextView tvMovieCountry;
    private TextView tvMovieGenre;
    private TextView tvMovieScore;
    private TextView tvMovieOverview;
    private String movieId;
    private List<HashMap<String,String>> castListArray = new ArrayList<>();
    private List<HashMap<String, ?>> directorListArray = new ArrayList<>();
    private ListView castListLV;
    private ListView directorListLV;
    private Button addToWatchList;
    private Button addToMemoir;
    private RatingBar ratingBar;
    private String imgURL;
    //private int watchId;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstance){
        movieView = inflater.inflate(R.layout.activity_fragment_movie_details,container,false);
        tvMovieName = (TextView) movieView.findViewById(R.id.movieNameInDetails);
        tvMovieReleaseDate = (TextView) movieView.findViewById(R.id.movieReleaseDateInDetails);
        tvMovieCountry = (TextView) movieView.findViewById(R.id.movieCountryInDetails);
        tvMovieGenre = (TextView) movieView.findViewById(R.id.movieGenreInDetails);
        tvMovieScore = (TextView) movieView.findViewById(R.id.ratingScoreInDetails);
        tvMovieOverview = (TextView) movieView.findViewById(R.id.movieOverviewInDetails);
        castListLV = (ListView) movieView.findViewById(R.id.castListInDetails);
        directorListLV = (ListView) movieView.findViewById(R.id.directorListInDetails);
        addToWatchList = (Button) movieView.findViewById(R.id.addToMovieListButton);
        addToMemoir = (Button) movieView.findViewById(R.id.addToMemoirButton);
        ratingBar = (RatingBar) movieView.findViewById(R.id.ratingBarInDetails);
        if(getArguments() != null){
            movieId = getArguments().getString("idOfMovie");
            String mn = getArguments().getString("nameOfMovie");
            if(getArguments().getString("key").equals("false")){
                addToWatchList.setVisibility(View.INVISIBLE);
            }
            tvMovieName.setText(mn);
            new AsyncGetDetails().execute(movieId);
            addToWatchList.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    new check().execute(String.valueOf(Login.personid));
                }
            });
        }
        return movieView;
    }

    private class AsyncGetDetails extends AsyncTask<String, Void, String>{

        @Override
        protected String doInBackground(String... params) {
            return MovieSearchAPI.getMovieData(params[0]);
        }

        protected void onPostExecute(String res){
            RES = res;
            new AsyncGetCast().execute(movieId);
        }
    }

    private class AsyncGetCast extends AsyncTask<String, Void, String>{

        @Override
        protected String doInBackground(String... params) {
            return MovieSearchAPI.getMovieCast(params[0]);
        }

        protected void onPostExecute(String res){
            HashMap<String, Object> cleanedMap = MovieSearchAPI.movieDataFilt(RES,res);
            imgURL = cleanedMap.get("imgURL").toString();
            releaseDate = cleanedMap.get("release date").toString();
            tvMovieReleaseDate.setText(cleanedMap.get("release date").toString());
            tvMovieGenre.setText(cleanedMap.get("genre").toString());
            tvMovieCountry.setText(cleanedMap.get("country").toString());
            tvMovieOverview.setText(cleanedMap.get("overview").toString());

            Object objCast = cleanedMap.get("castList");
            List<String> castInfo = (ArrayList) objCast;
            int ci = 0;
            while(ci < castInfo.size()){
                HashMap<String, String> hmap = new HashMap<>();
                hmap.put("castList",castInfo.get(ci));
                castListArray.add(hmap);
                ci++;
            }
            String[] header = new String[]{"castList"};
            int[] data = new int[]{R.id.castNameTextView};
            SimpleAdapter saCast = new SimpleAdapter(FragmentMovieDetails.this.getActivity(),castListArray,R.layout.list_cast,header,data);
            castListLV.setAdapter(saCast);

            Object objDirector = cleanedMap.get("directorList");
            List<String> directorInfo = (ArrayList) objDirector;
            int di = 0;
            while(di < directorInfo.size()){
                HashMap<String, String> hmap = new HashMap<>();
                hmap.put("directorList",directorInfo.get(di));
                directorListArray.add(hmap);
                di++;
            }
            String[] Dheader = new String[]{"directorList"};
            int[] Ddata = new int[]{R.id.castNameTextView};
            SimpleAdapter saDirector = new SimpleAdapter(FragmentMovieDetails.this.getActivity(),castListArray,R.layout.list_cast,Dheader,Ddata);
            directorListLV.setAdapter(saDirector);

            Float f = Float.parseFloat(cleanedMap.get("rating score").toString());
            tvMovieScore.setText(cleanedMap.get("rating score").toString());
            ratingBar.setRating(f);

        }
    }

    private class check extends AsyncTask<String, Void, List<WatchList>>{
        @Override
        protected List<WatchList> doInBackground(String... personid){
            List<WatchList> wl = MenuFragment.watchListViewModel.getWatchListById(personid[0]);
            return wl;
        }
        @Override
        protected void onPostExecute(List<WatchList> watchList){
            boolean notExist = true;
            for(WatchList w:watchList)
                if(w.getMovieid().equals(movieId)){
                    Toast toast = Toast.makeText(movieView.getContext(),"The movie already exists",Toast.LENGTH_SHORT);
                    toast.show();
                    notExist = false;
                    break;
                }
            if(notExist){
                Date date = new Date();
                SimpleDateFormat spDate = new SimpleDateFormat("yyyy-MM-dd");
                SimpleDateFormat spTime = new SimpleDateFormat("HH:mm:ss");
                String insertDate = spDate.format(date.getTime());
                String insertTime = spTime.format(date.getTime());
                WatchList finalWatchList = new WatchList();
                finalWatchList.setAddDate(insertDate);
                finalWatchList.setAddTime(insertTime);
                finalWatchList.setMovieid(movieId);
                finalWatchList.setMovieName(tvMovieName.getText().toString());
                finalWatchList.setReleaseDate(tvMovieReleaseDate.getText().toString());
                finalWatchList.setPersonid(String.valueOf(Login.personid));
                MenuFragment.watchListViewModel.insert(finalWatchList);
                Toast.makeText(movieView.getContext(),"Movie added successfully",Toast.LENGTH_SHORT).show();
            }
        }

    }
}
